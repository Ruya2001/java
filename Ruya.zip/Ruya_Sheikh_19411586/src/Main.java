import java.util.*;
import java.text.*;
import java.nio.file.*;
import java.io.IOException;

/**
 * Main class used for running
 * <p>
 * ID 19411586
 * author Ruya Sheikh Bafadel
 */
public class Main {
    private static final ArrayList<Flight> flights = new ArrayList<>(); // All data stored in one collection
    private static final Scanner sc = new Scanner(System.in);

    /**
     * main method for configuration
     *
     * @param args unused
     */
    public static void main(String[] args) throws Exception {
        int choice;  // to save the user choice from menu
        do {
            System.out.print("\n\t*** Welcome to Flights Management System ***\n\n" +
                    "Press ‘1’ to offer a new flight\n" +
                    "Press ‘2’ to add a passenger to a specified flight\n" +
                    "Press ‘3’ to remove a passenger from a specified flight\n" +
                    "Press ‘4’ to retrieve the average number of passengers per flight\n" +
                    "Press ‘5’ to display all available flights\n" +
                    "Press ‘6’ to save all the data into a text file\n" +
                    "Press ‘0’ to exit the system\n" +
                    "Your Choice: ");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    offerFlight();
                    break;
                case 2:
                    addPassenger();
                    break;
                case 3:
                    removePassenger();
                    break;
                case 4:
                    averagePassengers();
                    break;
                case 5:
                    displayFlights();
                    break;
                case 6:
                    saveFile();
                    break;
                case 0:
                    System.out.println("Good Bye...");
                    break;
                default:
                    System.out.println("Invalid Input!");
            }
        } while (choice != 0);
    }

    /**
     * create a new flight and add to arraylist
     *
     * @throws ParseException in case user entered date in invalid format
     */
    private static void offerFlight() throws ParseException {
        int id;
        int age;
        String name;
        boolean isCivilian;
        Pilot pilot;
        System.out.print("Enter the pilot id: ");
        id = sc.nextInt();
        System.out.print("Enter the pilot age: ");
        age = sc.nextInt();
        System.out.print("Enter the pilot name: ");
        name = sc.next();
        System.out.print("Is this pilot civilian or martial? (C/M) ");
        isCivilian = !sc.next().equalsIgnoreCase("M");
        pilot = new Pilot(id, age, name, isCivilian);

        int flightNumber, capacity;
        String sourceCountry;
        String destinationCountry;
        System.out.print("Enter capacity of the passengers: ");
        capacity = sc.nextInt();
        System.out.print("Enter source country: ");
        sourceCountry = sc.next();
        System.out.print("Enter destination country: ");
        destinationCountry = sc.next();
        System.out.print("Enter date of the flight 'yyyy-MM-dd': ");
        String dateString = sc.next();
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(dateString);
        boolean isFound;
        do {
            isFound = false;
            System.out.print("Enter flight number: ");
            flightNumber = sc.nextInt();
            for (Flight flight : flights) {
                if (flight.getDate().equals(date) && flight.getNumber() == (flightNumber)) {
                    System.out.println("Flight Number Must Be Unique!");
                    isFound = true;
                }
            }
        } while (isFound);
        flights.add(new Flight(flightNumber, capacity, sourceCountry, destinationCountry, date, pilot));
        Collections.sort(flights);
        System.out.println("Flight #" + flightNumber + " was added successfully!");
    }

    /**
     * add a new passenger into the selected flight
     */
    private static void addPassenger() {
        int flightNumber;
        int age;
        int passportNumber;
        String name;
        boolean isBusiness;
        Passenger passenger;
        System.out.print("Enter the passenger age: ");
        age = sc.nextInt();
        System.out.print("Enter the passenger passport number: ");
        passportNumber = sc.nextInt();
        System.out.print("Enter the passenger name: ");
        name = sc.next();
        System.out.print("Is this passenger needs business or normal seat? (B/N) ");
        isBusiness = !sc.next().equalsIgnoreCase("N");
        passenger = new Passenger(age, passportNumber, name, isBusiness);

        System.out.print("Enter number of the passenger flight: ");
        flightNumber = sc.nextInt();

        for (Flight flight : flights) {
            for (Passenger passenger1 : flight.getPassengers()) {
                if (passenger1.getPassportNumber() == passportNumber) {
                    System.out.println("Passenger with this this passport number already exists!");
                    return;
                }
            }
        }
        for (Flight flight : flights) {
            if (flight.getNumber() == flightNumber && flight.getPassengersCapacity() > flight.getPassengers().size()) {
                flight.addPassenger(passenger);
                break;
            }
        }
        System.out.println("Passenger " + name + " was added successfully!");
    }

    /**
     * remove a specific passenger from the chosen flight
     */
    private static void removePassenger() {
        System.out.print("Enter date of the passenger flight number: ");
        int flightNumber = sc.nextInt();
        System.out.print("Enter the passenger passport number to be removed: ");
        int passportNumber = sc.nextInt();

        for (Flight flight : flights) {
            if (flight.getNumber() == flightNumber) {
                for (int i = 0; i < flight.getPassengers().size(); i++) {
                    if (flight.getPassengers().get(i).getPassportNumber() == passportNumber) {
                        System.out.println("Passenger " + flight.getPassengers().get(i).getName() + " was removed successfully!");
                        flight.removePassenger(flight.getPassengers().get(i));
                        return;
                    }
                }
            }
        }
        System.out.println("Couldn't Find Passenger!");
    }

    /**
     * get average of passengers per flight in a given date
     *
     * @throws ParseException in case user entered date in invalid format
     */
    private static void averagePassengers() throws ParseException {
        System.out.print("Enter date to get average passengers 'yyyy-MM-dd': ");
        String dateString = sc.next();
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(dateString);
        int sumOfFlights = 0, sumOfPassengers = 0;
        for (Flight flight : flights) {
            if (flight.getDate().equals(date) && flight.getPassengers().size() > 0) {
                sumOfPassengers += flight.getPassengers().size();
                sumOfFlights++;
            }
        }
        System.out.println("Average number of passengers per flight is "
                + ((float) sumOfPassengers / sumOfFlights)
                + " passenger per flight");
    }

    /**
     * print all flights
     */
    private static void displayFlights() {
        for (Flight flight : flights) {
            System.out.println(flight.toString());
        }
    }

    /**
     * store the flights' data into a selected file
     *
     * @throws IOException in case user entered invalid file
     */
    private static void saveFile() throws IOException {
        System.out.print("Enter name of file to save data? ");
        String filename = sc.next();
        Files.write(Paths.get(filename + ".txt"), ("").getBytes());
        for (Flight flight : flights) {
            Files.write(Paths.get(filename + ".txt"), (flight.toString() + '\n').getBytes(), StandardOpenOption.APPEND);
        }
        System.out.println("Data was saved to file successfully!");
    }
}
