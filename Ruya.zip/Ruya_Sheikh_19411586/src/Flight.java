import java.util.ArrayList;
import java.util.Date;

/**
 * Flight class to hold objects of flights
 */
public class Flight implements Comparable<Flight> { // Comparable is used to sort flights by dates
    private int number;
    private int passengersCapacity;
    private String sourceCountry;
    private String destinationCountry;
    private Date date;
    private Pilot pilot;
    private ArrayList<Passenger> passengers;

    public Flight(int number, int passengersCapacity, String sourceCountry, String destinationCountry, Date date, Pilot pilot) {
        this.number = number;
        this.passengersCapacity = passengersCapacity;
        this.sourceCountry = sourceCountry;
        this.destinationCountry = destinationCountry;
        this.date = date;
        this.pilot = pilot;
        passengers = new ArrayList<>();
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getPassengersCapacity() {
        return passengersCapacity;
    }

    public void setPassengersCapacity(int passengersCapacity) {
        this.passengersCapacity = passengersCapacity;
    }

    public String getSourceCountry() {
        return sourceCountry;
    }

    public void setSourceCountry(String sourceCountry) {
        this.sourceCountry = sourceCountry;
    }

    public String getDestinationCountry() {
        return destinationCountry;
    }

    public void setDestinationCountry(String destinationCountry) {
        this.destinationCountry = destinationCountry;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Pilot getPilot() {
        return pilot;
    }

    public void setPilot(Pilot pilot) {
        this.pilot = pilot;
    }

    public ArrayList<Passenger> getPassengers() {
        return passengers;
    }

    public void setPassengers(ArrayList<Passenger> passengers) {
        this.passengers = passengers;
    }

    /**
     * @param passenger a new passenger to be added
     */
    public void addPassenger(Passenger passenger) {
        this.passengers.add(passenger);
    }

    /**
     * @param passenger a selected passenger to be removed
     */
    public void removePassenger(Passenger passenger) {
        this.passengers.remove(passenger);
    }

    @Override
    public String toString() {
        return "\nFlight{\n" +
                "number=" + number +
                ", \npassengersCapacity=" + passengersCapacity +
                ", \nsourceCountry='" + sourceCountry + '\'' +
                ", \ndestinationCountry='" + destinationCountry + '\'' +
                ", \ndate=" + date +
                ", \npilot=" + pilot +
                ", \npassengers=" + passengers +
                "\n}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flight flight = (Flight) o;
        return number == flight.number && passengersCapacity == flight.passengersCapacity && sourceCountry.equals(flight.sourceCountry) && destinationCountry.equals(flight.destinationCountry) && date.equals(flight.date) && pilot.equals(flight.pilot) && passengers.equals(flight.passengers);
    }

    /**
     * Used to sort flights with dates
     *
     * @param o an object of flight to compare if older
     * @return a result of comparison if 1=> greater 0=> equals or -1=> smaller
     */
    @Override
    public int compareTo(Flight o) {
        return getDate().compareTo(o.getDate());
    }
}
