import java.util.*;
import java.text.*;
import java.nio.file.*;
import java.io.IOException;

/**
 * TestClass used for testing
 * <p>
 * ID 19411586
 * author Ruya Sheikh Bafadel
 */
public class TestClass {
    private static final ArrayList<Flight> flights = new ArrayList<>(); // All data stored in one collection

    /**
     * main method for configuration
     *
     * @param args unused
     */
    public static void main(String[] args) throws Exception {
        // Create at least 7 flights in at least 3 different dates and add them to the collection that
        Pilot pilot1 = new Pilot(999, 88, "Ahmed", true);
        Pilot pilot2 = new Pilot(888, 77, "Mohamed", false);
        Pilot pilot3 = new Pilot(777, 66, "Salah", true);
        Pilot pilot4 = new Pilot(666, 55, "Riyad", false);
        Pilot pilot5 = new Pilot(555, 44, "Abbas", true);
        Pilot pilot6 = new Pilot(444, 33, "Salam", false);
        Pilot pilot7 = new Pilot(333, 30, "Amir", true);

        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = sdf.parse("2020-11-23");
        Date date2 = sdf.parse("2021-09-10");
        Date date3 = sdf.parse("2022-02-07");

        Flight flight1 = new Flight(9, 100, "Bahrain", "Qatar", date1, pilot1);
        Flight flight2 = new Flight(8, 200, "Iraq", "Oman", date1, pilot2);
        Flight flight3 = new Flight(7, 300, "Jordan", "Lebanon", date2, pilot3);
        Flight flight4 = new Flight(6, 400, "Kuwait", "Jordan", date2, pilot4);
        Flight flight5 = new Flight(5, 500, "Lebanon", "Kuwait", date3, pilot5);
        Flight flight6 = new Flight(4, 600, "Oman", "Iraq", date3, pilot6);
        Flight flight7 = new Flight(3, 700, "Qatar", "Bahrain", date3, pilot7);

        flights.add(flight1);
        flights.add(flight2);
        flights.add(flight3);
        flights.add(flight4);
        flights.add(flight5);
        flights.add(flight6);
        flights.add(flight7);

        // Try to violate the state of the objects and show that your code prevents all violations.
        Passenger passenger1 = new Passenger(22, 23456, "Ekram", true);
        Passenger passenger2 = new Passenger(23, 34567, "Fouad", false);
        Passenger passenger3 = new Passenger(24, 45678, "Ismail", true);
        Passenger passenger4 = new Passenger(25, 56789, "Nazif", false);
        Passenger passenger5 = new Passenger(26, 67890, "Makka", true);
        Passenger passenger6 = new Passenger(27, 78901, "Ruya", false);
        Passenger passenger7 = new Passenger(34, 89012, "Rashad", true);
        Passenger passenger8 = new Passenger(35, 90123, "Samir", false);
        Passenger passenger9 = new Passenger(36, 12345, "Tayeb", true);
        Passenger passenger10 = new Passenger(37, 23456, "Zaki", false);

        addPassenger(passenger1, flight1);
        addPassenger(passenger2, flight2);
        addPassenger(passenger3, flight3);
        addPassenger(passenger4, flight4);
        addPassenger(passenger5, flight5);
        addPassenger(passenger6, flight6);
        addPassenger(passenger7, flight7);
        addPassenger(passenger8, flight1);
        addPassenger(passenger9, flight2);
        addPassenger(passenger10, flight2);

        removePassenger(passenger9, flight1);
        removePassenger(passenger9, flight2);

        averagePassengers(date1);
        averagePassengers(date2);
        averagePassengers(date3);

        // Show that the other operations that happen frequently are working fine
        System.out.println();
        displayFlights();
        // At the end, the whole data should be saved into a text file
        // and this file should be saved automatically inside the folder contains your Java project
        saveFile();
    }

    /**
     * add a new passenger into the selected flight
     */
    private static void addPassenger(Passenger passenger, Flight flight1) {
        for (Flight flight : flights) {
            for (Passenger passenger1 : flight.getPassengers()) {
                if (passenger1.getPassportNumber() == passenger.getPassportNumber()) {
                    System.out.println("Passenger with this this passport number already exists!");
                    return;
                }
            }
        }
        for (Flight flight : flights) {
            if (flight.getNumber() == flight1.getNumber() && flight.getPassengersCapacity() > flight.getPassengers().size()) {
                flight.addPassenger(passenger);
                break;
            }
        }
        System.out.println("Passenger was added successfully!");
    }

    /**
     * remove a specific passenger from the chosen flight
     */
    private static void removePassenger(Passenger passenger, Flight flight1) {
        for (Flight flight : flights) {
            if (flight.getNumber() == flight1.getNumber()) {
                for (int i = 0; i < flight.getPassengers().size(); i++) {
                    if (flight.getPassengers().get(i).getPassportNumber() == passenger.getPassportNumber()) {
                        System.out.println("Passenger " + flight.getPassengers().get(i).getName() + " was removed successfully!");
                        flight.removePassenger(flight.getPassengers().get(i));
                        return;
                    }
                }
            }
        }
        System.out.println("Couldn't Find Passenger!");
    }

    /**
     * get average of passengers per flight in a given date
     */
    private static void averagePassengers(Date date) {
        int sumOfFlights = 0, sumOfPassengers = 0;
        for (Flight flight : flights) {
            if (flight.getDate().equals(date) && flight.getPassengers().size() > 0) {
                sumOfPassengers += flight.getPassengers().size();
                sumOfFlights++;
            }
        }
        System.out.println("Average number of passengers per flight is "
                + ((float) sumOfPassengers / sumOfFlights)
                + " passenger per flight");
    }

    /**
     * print all flights
     */
    private static void displayFlights() {
        for (Flight flight : flights) {
            System.out.println(flight.toString());
        }
    }

    /**
     * store the flights' data into a selected file
     *
     * @throws IOException in case user entered invalid file
     */
    private static void saveFile() throws IOException {
        Files.write(Paths.get("test.txt"), ("").getBytes());
        for (Flight flight : flights) {
            Files.write(Paths.get("test.txt"), (flight.toString() + '\n').getBytes(), StandardOpenOption.APPEND);
        }
        System.out.println("Data was saved to file successfully!");
    }
}
