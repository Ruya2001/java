
/**
 * Pilot class to hold objects of pilots
 */
public class Pilot {
    private int id;
    private int age;
    private String name;
    private boolean isCivilian;

    public Pilot(int id, int age, String name, boolean isCivilian) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.isCivilian = isCivilian;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isCivilian() {
        return isCivilian;
    }

    public void setCivilian(boolean civilian) {
        isCivilian = civilian;
    }

    @Override
    public String toString() {
        return "\n\tPilot{" +
                "\n\tid=" + id +
                ", \n\tage=" + age +
                ", \n\tname='" + name + '\'' +
                ", \n\tisExperienced=" + isCivilian +
                "\n\t}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pilot pilot = (Pilot) o;
        return id == pilot.id && age == pilot.age && isCivilian == pilot.isCivilian && name.equals(pilot.name);
    }
}
