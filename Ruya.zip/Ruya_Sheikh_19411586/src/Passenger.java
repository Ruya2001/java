
/**
 * Passenger class to hold objects of passengers
 */
class Passenger {
    private int age;
    private int passportNumber;
    private String name;
    private boolean isBusiness;

    public Passenger(int age, int passportNumber, String name, boolean isBusiness) {
        this.age = age;
        this.passportNumber = passportNumber;
        this.name = name;
        this.isBusiness = isBusiness;
    }

    public int getAge() {
        return age;
    }

    public int getPassportNumber() {
        return passportNumber;
    }

    public String getName() {
        return name;
    }

    public boolean isBusiness() {
        return isBusiness;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setPassportNumber(int passportNumber) {
        this.passportNumber = passportNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBusiness(boolean business) {
        isBusiness = business;
    }

    @Override
    public String toString() {
        return "\n\tPassenger{" +
                "\n\tage=" + age +
                ", \n\tpassportNumber=" + passportNumber +
                ", \n\tname='" + name + '\'' +
                ", \n\tisBusiness=" + isBusiness +
                "\n\t}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Passenger passenger = (Passenger) o;
        return age == passenger.age && passportNumber == passenger.passportNumber && isBusiness == passenger.isBusiness && name.equals(passenger.name);
    }

}
